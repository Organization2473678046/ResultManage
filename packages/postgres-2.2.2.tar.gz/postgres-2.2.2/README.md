postgres is a high-value abstraction over psycopg2

[Read the Docs](https://postgres-py.readthedocs.org)
